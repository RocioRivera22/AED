/* Ejemplos de valores y Operaciones de tipos de datos
* Rivera, Rocio Micaela

*/

#include <iostream>

int main()
{
    std::cout << "Ejemplo de variables en C++\n\n";

    std::cout << "Las variables en C++ son las siguientes:\n";
    std::cout << "1- Para variables BOOL\n";
    std::cout << "2- Para variables CHAR\n";
    std::cout << "3- Para variables UNSIGNED\n";
    std::cout << "4- Para variables INT\n";
    std::cout << "5- Para variables DOUBLE\n";
    std::cout << "6- Para variables STRING\n \n";

    std::cout << "Ejemplos:\n";
    std::cout << "1- Almacena 1 o 0 dependiendo si la variable es True(1) o False(0)\n";
    std::cout << "2- Almacena caracteres: C, c, A, a, B, c\n";
    std::cout << "3- Almacena numeros positivos y el 0: 0, 1, 2, 3, 4, 5\n";
    std::cout << "4- Amacena números enteros: 15, -1, 0, -20, 45\n";
    std::cout << "5- Almacena números que se aporximan a un real: 8.999999, 3.1452\n";
    std::cout << "6- Almacena una cadena de caracteres: 'Hola Mundo', 'Hello Wordl'\n";

    std::cout << "Tipo de operaciones\n";
    std::cout << "1- 3 > 4 = False(0)\n";
    std::cout << "2- A = A; A + b = 'Ab'\n";
    std::cout << "3- (4+6)/2 - 4 * 1 = 1\n";
    std::cout << "4- (-4)*2 = (-2)*4\n";
    std::cout << "5- Pi = 3.14159265359, 10/3=3.33333333\n";
    std::cout << "6- 'What + 'a ' + 'wonderfull ' + 'wordl' = What a wonderfull wordl, A = A\n";
}
